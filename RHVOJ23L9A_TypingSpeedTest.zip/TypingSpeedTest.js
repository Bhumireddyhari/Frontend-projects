let quoteDisplayEl = document.getElementById("quoteDisplay")
let timerEl = document.getElementById("timer")
let submitBtnEl = document.getElementById("submitBtn")
let quoteInputEl = document.getElementById('quoteInput')
let resultEl = document.getElementById("result")
let spinnerEl = document.getElementById("spinner")
let resetBtnEl = document.getElementById("resetBtn")
counter = 1
uniqueId = setInterval(function() {
    timerEl.textContent = counter + ' seconds'
    counter += 1
}, 1000)
fetchRandomJoke()

function fetchRandomJoke() {
    spinnerEl.classList.remove('d-none')
    options = {
        method: "GET"
    }
    fetch("https://apis.ccbp.in/random-quote", options)
        .then(function(response) {
            return response.json()
        })
        .then(function(jsonData) {
            spinnerEl.classList.add('d-none')
            quoteDisplayEl.textContent = (jsonData.content)
            console.log(jsonData.content)
        })

}
submitBtnEl.addEventListener("click", function() {
    clearInterval(uniqueId)

    if (quoteDisplayEl.textContent === quoteInputEl.value) {
        resultEl.textContent = 'You Typed In ' + timerEl.textContent
    } else {
        resultEl.textContent = "You Typed Incorrect Sentence"
    }

})
resetBtnEl.addEventListener("click", function() {
    fetchRandomJoke()
    counter = 1
    uniqueId = setInterval(function() {
        timerEl.textContent = counter + ' seconds'
        counter += 1
    }, 10000)
    quoteInputEl.value = ""
    resultEl.textContent = ""

})